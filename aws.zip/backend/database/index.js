module.exports = {
    userModel: require('./user.model')
}
