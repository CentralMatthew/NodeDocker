module.exports = {
    config: require('./config'),
    database: require('./database')
}
